# Ubuntu Tech Solutions Website

This project is a multi-page company website for Ubuntu Tech Solutions. It was designed to showcase the business as a professional technology and infrastructure company serving small businesses and growing organisations.

## Project Purpose

The website was created to present Ubuntu Tech Solutions as a modern technology partner offering:
- Website development
- Software solutions
- IT support
- Cloud infrastructure
- Cybersecurity
- IT consulting

The design uses a dark corporate theme with orange highlights to create a professional and technology-focused look.

## Pages Included

The website includes the following pages:
- Home
- About Us
- Services
- Portfolio
- Contact

## Design and Layout Changes Made

### 1. Modern Dark Theme
A dark background was applied throughout the site to create a sleek, premium technology look. The design uses:
- charcoal background colors
- orange accent colors for important elements
- light grey text for contrast
- subtle grid patterns to add visual interest

### 2. Sticky Navigation Bar
A navigation bar was added at the top of every page with:
- brand logo and company name
- page links
- a Get Started button
- sticky positioning so it stays visible while scrolling

### 3. Hero Sections
Each page includes a bold hero section with:
- large headline text
- highlighted orange text
- short business description
- call-to-action buttons
- status badge styling for a professional tech appearance

### 4. Service Page Enhancement
The Services page was redesigned to include:
- numbered service cards
- category labels
- service descriptions
- pricing boxes
- arrow call-to-action buttons
- a final custom solution section

### 5. About Us Page Storytelling Layout
The About page was built to reflect the company’s brand and values by including:
- company introduction
- origin story
- mission and vision
- values section
- growth-focused design structure

### 6. Portfolio Display
The portfolio page was created to highlight sample projects using:
- project cards
- project numbers
- descriptions
- tags for technologies and categories
- visual project images
- hover effects

### 7. Contact Page Form and Information
The Contact page includes:
- office location
- email address
- phone number
- business hours
- a contact form for customer enquiries
- a strong final callout message

### 8. Responsive Design
The website was made mobile-friendly by:
- stacking columns on smaller screens
- adjusting typography sizes
- hiding some navigation items on mobile
- resizing cards and sections for smaller devices

### 9. Buttons and Hover Effects
Interactive styling was added to improve the user experience, including:
- orange buttons
- hover color changes
- card hover effects
- border highlighting on interactive elements

## Styling Choices

The website uses a modern business aesthetic based on:
- dark background
- orange accent color
- neutral gray text
- clean spacing
- strong typography
- polished card layouts

## Technologies Used

- HTML
- CSS
- Responsive web design principles

## File Structure

```text
Ubuntu-Tech-Solutions/
│
├── home.html
├── about.html
├── services.html
├── portfolio.html
├── contact.html
│
├── css/
│   └── style.css
│
├── Images/
│   └── project images and visual assets
│
├── README.md
└── index.html